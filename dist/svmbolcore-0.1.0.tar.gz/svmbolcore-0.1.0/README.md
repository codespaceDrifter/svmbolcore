math library that symbolically solve algebra
expressions are immutable and always sorted
generate a tuple list that is able to be sorted
use dicts to do mul simplification and then add simplifaction

make my commits mean something dont just say drift
maybe rename to svmbolcore or something

# to do:
mul expand multiply to add nodes



